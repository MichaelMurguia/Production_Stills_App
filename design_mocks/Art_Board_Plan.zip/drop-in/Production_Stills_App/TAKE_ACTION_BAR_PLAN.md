# TAKE_ACTION_BAR_PLAN.md — one verdict, two lists, no wrap

**For the coding agent.** Read `app/static/DESIGN_SYSTEM.md` first. Mock:
`design_mocks/17a-take-action-bar.png`. Touches `app/static/app.js`
(the staged-candidate block, ~L7027–7130), `app/static/styles.css`
(`.act-bar` and friends, ~L1640–1670), and the take-action tests.

---

## The defect, and where it came from

T2 (`TAKE_ACTIONS`, 2026-08-06) ruled that the bar's verbs "render in one
grammar," reasoning from the source: *they are all `mk(…, "ghost")`, so a
bare text link among them states a hierarchy the code does not have.*

That reasoning inverted the direction of authority. **The code was wrong,
and the design conformed to it.** Seven verbs are not peers — one of them
is the verdict the whole screen exists to collect, and the other six are
things you might do to the take or make from it. The row now reads as
seven identical boxes, of which two wrap to a second line, and the eye
has to read every label before it can find the decision.

The rule this canonizes, stated once:

> **The code is not the authority on hierarchy — the decision is.** When
> the source renders as peers things the user does not experience as
> peers, the source is what changes. A shared constructor is an
> implementation fact, never a design argument.

Fold that beside *verb-sits-with-its-object* (2026-08-07). T2's *must not
wrap / never scroll* holds and is strengthened here; only its
one-grammar clause is superseded.

## The ruling

**One boxed, amber verdict. Six text acts in two labelled groups. Reject
fenced right.** Per `17a-take-action-bar.png`, left to right:

| zone | contents | treatment |
|---|---|---|
| `.act-approve` | `Approve panel` | **filled amber**, `--field` text. The screen's only amber, as canon already says |
| rule | | `1px var(--line)` |
| `.act-use` | `USE` kicker · `Full-size take` · `Repair region` | `.text-act`, `--ink` |
| rule | | |
| `.act-derive` | `DERIVE` kicker · `Reference` · `Crop to reference` · `Light study` | `.text-act`, `--ink-dim` |
| spacer | `flex:1` | |
| rule | | |
| `.act-right` | `Reject` | `.text-act`, `--ink-dim`; `--bad` on hover only |

Four consequences to implement deliberately:

1. **Approve becomes amber and filled.** It is currently
   `border:1px solid var(--ok)` — green, bordered, visually a peer of the
   six. `--ok` is the *state* colour of an approved panel; it is not the
   colour of the act that approves it. Canon has said this screen's only
   amber is Approve panel; make the pixels agree. Delete
   `.act-bar .act-approve-btn`.
2. **The groups get Courier kickers** (`9px`, `.14em`, `--ink-faint`).
   They are what makes six text acts legible as two short lists rather
   than one run of links — and they say the thing the labels cannot:
   USE produces another take *of this panel*, DERIVE produces a record
   *somewhere else*. That is also why DERIVE reads dimmer: nothing in it
   advances this panel toward approval.
3. **Arrows come off every label.** `→ Full-size take`, `→ Reference`,
   `→ Light study` lose theirs; `Crop → reference` becomes
   `Crop to reference`. One arrow marks a promotion; six mark nothing.
   (This supersedes the 2026-08-06 line keeping "mock-sanctioned arrows"
   — the mock that sanctioned them had two, not six.)
4. **Disabled state is unchanged.** `Reference` stays disabled until the
   panel is approved, with its title as the explanation; a gate reads as
   disabled state, never a surprise error. `Delete forever` still appears
   in `.act-right` only when the staged take is REJECTED, left of Reject,
   and keeps `.danger`.

### `mk()` gains a kind

`mk(label, cls, fn, opts)` keeps its signature; the call sites change
class:

```js
mk("Approve panel", "primary act-approve-btn", …)   // was "ghost"
mk("Full-size take", "text-act", …)                 // was "ghost"
mk("Repair region",  "text-act", …)
mk("Reference",      "text-act act-dim", …)
mk("Crop to reference", "text-act act-dim", …)
mk("Light study",    "text-act act-dim", …)
mk("Reject",         "text-act act-reject", …)
```

`.text-act` already exists; add only `.act-dim { color: var(--ink-dim) }`
and the kicker rule. Everything the buttons *do* is untouched — same
handlers, same modals, same endpoints.

## Why it cannot wrap again

Text acts cost their words, not a padded box each. The row measures well
under the stage column at every supported width, so `flex:1` on the
spacer absorbs the slack and Reject stays pinned right instead of the row
justifying itself into two lines.

- Every label is `white-space: nowrap`.
- `.act-bar` keeps `flex-wrap: wrap` as the last-resort behaviour, but the
  **first** response to a narrow stage is `.act-derive` collapsing to a
  `⋯` menu (its three verbs, in order) — a group folding is legible; a
  row breaking mid-list is not. Threshold: when `.act-bar`'s content
  width would exceed its box. Verify with a `ResizeObserver` on the
  stage, not a media query — the rail and side panel both change the
  stage's width without changing the viewport's.

## Tests

- `tests/test_design_tokens.py` — `.act-bar .ghost` no longer exists;
  `.act-approve-btn` has no `--ok` border; `.act-dim` resolves to
  `--ink-dim`; no `.act-bar` descendant has a `border-radius`.
- `tests/test_take_actions.py` — the bar renders exactly one `.primary`;
  six `.text-act`; the DERIVE group holds three; `Reject` is the last
  child of `.act-right`; no label contains `→`.
- Add: a stage narrowed below the row's content width renders
  `.act-derive` as a single `⋯` trigger and the row still occupies one
  line. Existing assertions that count seven `.ghost` buttons are
  superseded — rewrite them to the above rather than deleting them.

---

## Canon

Fold into the judging-room section, replacing T2's one-grammar clause:

> **The code is not the authority on hierarchy — the decision is.** A
> shared constructor is an implementation fact, not a design argument.

> The take bar is **one verdict and two lists**: the amber verdict, USE
> (acts producing another take of this panel), DERIVE (acts producing a
> record elsewhere, dimmed), and Reject fenced right. A group collapses
> to `⋯` before the row wraps.

Changelog:
`**2026-08-08** — Take action bar: Approve panel becomes the filled amber
verdict, the six remaining verbs become text acts in labelled USE and
DERIVE groups, arrows dropped, DERIVE collapses to ⋯ before the row
wraps. T2's one-grammar clause superseded; decision-not-code-owns-
hierarchy canonized.`

Then delete this file.

# CANONIZATION_PASS_2026-08-10.md — nine rows ruled

**For the coding agent.** Every row in `DESIGN_SYSTEM.md` → `## Uncanonized
patterns` is ruled below. Fold each ruling into the section named, delete the
row, then delete this file.

Mocks in `design_mocks/`:

| mock | ruling it draws |
|---|---|
| `au-lb-amber-ledger.png` | R1 — the five amber spends, each ruled |
| `au-lb-rail.png` | R1 — the composer rail with two amber marks left |
| `au-lb-geometry.png` | R2 — one geometry, declared by the renderer |
| `au-ref-register.png` | R4 — unanchored places as a register, not cards |
| `au-ref-style-shelf.png` | R5 — the ramps take the STYLE shelf |
| `au-wb-camera.png` | R7 — camera axes stated, opened, and gated |
| `au-wb-brief.png` | R3 — the brief keeps its cell, and says why |

Also in the drop-in: `SHEET_SYSTEM_PLAN.md`. Its **lookbook half has shipped**
and is reviewed here (R1, R2). Its board half — `/api/specs/{id}/arrange`, the
`BOARD` archetype, the `INK` default, the type-floor correction to
`assemble._type_scale` — is not yet in the tree. Delete that plan and its
`lb-*` / `ba-*` mocks when the board half lands, not before.

---

## R1 — Lookbook composer: amber. **Exemption refused.**

The row asks for amber beyond the app's three roles "per the plan's own
§8/§11". The plan does not get to grant that; the two rules everything derives
from are not per-feature. Five spends, ruled (`au-lb-amber-ledger.png`):

| spend | role | ruling |
|---|---|---|
| selection outline | **focus** | keep — the selected block is where the keyboard and rail point |
| Export when ready | **primary act** | keep — one filled button, and the view's reason to exist |
| block type chip | none, it is a label | Courier `--ink` on `rgba(11,12,14,.82)`, `--line` border |
| `AUTHORED` chip | none, it is a fact | Courier `--ink-dim`, no chip frame |
| take-the-new-line | not this view's act | ghost, matching `Keep and author` |

Two survive. The `AUTHORED` one is the load-bearing correction: canon already
says *amber marks what blocks; a report has no amber*, and an authored caption
blocks nothing — it records who wrote the line. `SOURCE MOVED` keeps `--bad`,
because that one does block export.

The block chip becomes the **tags-ride-the-image** vocabulary (T1) that already
solved identity-over-a-picture. Do not invent a third treatment: outline says
*which* block, chip says *what* it is, one job each.

Implementation: `.ov-block.sel` keeps `border-color: var(--accent)`. Remove
`--accent` from the block chip, the `AUTHORED` chip and the rebind button; the
rail's only amber is the export button. Expect the amber-budget test (if it
counts per view) to go from 5 to 2.

## R2 — Lookbook composer: overlay drift. **Not a tolerance. Two geometries.**

The row offers to "mirror the renderer's inner offsets". Refused as framed: the
few pixels are the symptom, and the disease is that block rects are computed in
Python for drawing and again in JS for aiming.

**Ruled: the renderer emits the rects it drew.** `render_sheet` returns a
geometry manifest alongside the image and the preview endpoint carries it:

```json
{"rects": [{"block_id": "B-0001",
            "outer": [0, 0, 1810, 812],
            "image": [0, 26, 1810, 742],
            "slots": [{"slot_id": "S1", "rect": [0, 26, 1120, 742]}]}]}
```

The overlay positions from `image`/`rect` scaled by the preview scale and
measures nothing. Same rule that already keeps preview and export honest: one
computation, two consumers. Aim becomes exact by construction, not calibration
— and headings/captions can be re-laid out later without the overlay knowing.

Test: for a headed block, the overlay rect equals the manifest rect exactly; no
JS packing function survives in the lookbook view.

## R3 — Editable panel brief. **In-place editor is correct. Canon clarified.**

The row worries it violates *edit a paragraph in a room, not in a cell*. Read in
full, that canon exists for prose **other records inherit**, so the save can
state its blast radius before it fires — the environment editor is the case that
names it. A panel brief is inherited by nothing: it feeds this panel's next take
and no other record.

Keep `.brief-row` / `.brief-editor` as built. One copy change: the Courier line
becomes `JOURNALED · NEXT TAKE PAINTS FROM THE NEW BRIEF · NOTHING ELSE
INHERITS IT` (`au-wb-brief.png`) — six words that make the next reader's
question answer itself.

Canon amendment, in Layout patterns beside the room rule: **a room is owed when
other records inherit the prose; prose only its own record reads is edited in
place.** The discriminator is inheritance, not length.

## R4 — Unanchored locations. **Full pass: a register, not uncast cards.**

Ruled against two existing canons at once. *An empty state never reserves the
shape of the missing thing* — an uncast-style card is an image-sized well whose
only message is that there is no image. And *a card is for a thing with a
picture*: a place with no reference has nothing to judge, so a card invites a
judgement that cannot be made.

**Ruled** (`au-ref-register.png`): unanchored places render as a **labelled
table** (D4 vocabulary, already canon) beneath the SCENES card grid.

- Grid tracks `minmax(0,1fr) 130px 210px 170px` — place, scene count,
  environment, act.
- Courier header row on `--field`; rows separated by `--line-soft`; the page
  scrolls, the table does not.
- One act per row, `Add reference` as a text act at the row's end, prefilling
  `LOCATION_GEOMETRY — <NAME>` as built.
- Section label `UNANCHORED · FROM THE SCREENPLAY'S SLUGLINES`, with one plain
  line stating what the reader is looking at.
- Shelf count keeps `N ANCHORED · M LOCATIONS UNANCHORED`. That count is a
  **finding about the production**, not an apology — leave it factual.

**And the open question is answered: no own shelf.** A register is not a peer of
the cast shelves; it is the SCENES shelf's unfinished business and belongs under
the shelf that would hold the answers. Casting stays subjects-only, as built.

Delete the uncast-card path for locations; keep search over place names and
environments.

## R5 — Swatch ramps on STYLE. **The ramps are the shelf.**

Nineteen cards restating three ramps is the wall the ramps were added to fix;
keeping both leaves the duplication in place, one row lower.

**Ruled** (`au-ref-style-shelf.png`): `.pal-shelf` **is** the STYLE shelf —
three ramps at 34px with the group name in Courier, a count, and `Open group`.
Individual plates live behind the group viewer, which already exists and already
shows them; no plate grid on the shelf.

Quarantined swatches keep their cards, below, under
`QUARANTINED · AWAITING A VERDICT` — *a verdict happens where the proposal is*
is already canon and this is the case that reuses it. A mixed group's count
reads `N PROVISIONAL` in `--bad` as built.

## R6 — Storage readout. **Delete the bar. Numbers only.**

Two canons decide this without argument. *The coverage meter is the project's
only meter vocabulary — never invent another bar.* And *the control panel
states, it never explains*: Settings' configured life is machine facts in
Courier.

**Ruled:** remove `.stor-bar` from `styles.css` and the markup. Storage is a
Courier line — `FREE 214 GB OF 500 GB · 57% USED` — over the existing by-kind
list. The health state rides that line's colour: no colour while healthy,
`--hold` when tight, `--bad` once a render would be refused. Same three states,
zero new vocabulary, and the number a user would read aloud is now the thing on
screen.

## R7 — Camera & composition axes. **Two presentations, by surface.**

Four live selects sit permanently open on three surfaces. On two of them that is
right; on the third it is not.

- **Look Interview** and **breakdown editor**: keep the full `.cam-row`. These
  surfaces exist to author these values.
- **Panels workbench**: collapses (`au-wb-camera.png`). The surface's job is
  judging takes, and in the common case all four axes are inherited and nothing
  is being changed. It shows **one Courier line with the verb beside it** —
  `EYE LEVEL · 24MM · LEVEL · WIDE — FROM BIBLE` / `Change camera` — and opens
  the four selects only when asked, with `Save camera` / `Cancel` and the
  existing journaling line. This matches the brief row directly above it, so
  two adjacent controlled edits read as one pattern.

Three states ship: inherited-and-stated, opened, and **fixed by an approved
take** — the act stays in place, disabled, with the condition in its `title`
(gate readable as state, as built).

Custom lens: keep the reveal, but the **summary states the millimetres, never
the word "Custom"** — a summary that says `CUSTOM` withholds the one fact it
exists to carry. Clamp the input and state its unit.

Copy: keep `— FROM BIBLE` and `— THIS PANEL` as the provenance suffix; they
answer "why does this say 24mm" without a sentence.

## R8 — Remembered reference selection. **Built from canon. Copy accepted.**

No markup, and the behaviour is right: a remembered decision outranks a matcher
default, and the hint states which rule is in force. The NO MATCHES warning
standing down when the empty selection is the user's own choice is the correct
reading of *amber marks what blocks* — the user's decision is not a problem.

One copy tighten: the hint should name the source, not the mechanism —
`RODE THE PREVIOUS TAKE` reads better than a clause about staying selected.
Fold into Components beside the workbench checkboxes and delete the row.

## R9 — Add a panel from the workbench. **Placement accepted.**

Header beside the breakdown selector is right: the act belongs with the
collection it extends, and an affordance at the end of a panel list would put a
create act in a table's last rows, which B4 forbids. Reuses `#sp-add-panel`
vocabulary and the canonical modal. Accepted as built; fold and delete.

## R10 — Board type on Auto Breakdown intake. **Move it above the brief.**

The row asks whether the select belongs beside Mode or above the brief. Above
the brief. The board's shape governs how the brief is read, and a control that
qualifies a field belongs before it — beside Mode it is found after the user has
already written the thing it changes the meaning of. Keep the `BOARD_TYPES`
vocabulary, the row-inferred default, and leave-alone-once-touched.

---

## Canon to add

Into **Layout patterns**:

1. **A card is for a thing with a picture.** Where a record has no image to
   judge, it is a row in a labelled table, not a card with an empty well. The
   register belongs under the shelf that would hold its answers, not beside it.
2. **A room is owed when other records inherit the prose.** Prose only its own
   record reads is edited in place. The discriminator is inheritance, not length.
3. **One control, two presentations.** A setting authored on one surface and
   merely in force on another shows its full controls where it is authored and a
   single stated line where it is inherited — with the verb beside the line.
   A summary always states the value, never the word "Custom".
4. **Geometry is computed once and declared.** When one component draws and
   another must aim at what was drawn, the drawer emits its rects and the aimer
   consumes them. Two implementations of one geometry is a drift bug with a
   permanent maintenance cost, not a tolerance to tune.

Into **Do not**:

5. **Do not grant a feature an exemption from the two rules.** A plan may not
   authorise amber outside its three roles; if a mark is not stage, primary act
   or focus, it is `--ink` or Courier.
6. **Do not add a second bar.** The coverage meter is the only meter. A capacity
   is a Courier number line whose colour carries its state.
